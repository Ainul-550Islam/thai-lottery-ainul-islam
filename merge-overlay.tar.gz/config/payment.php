<?php

use App\Enums\PaymentMethod;
use App\Support\Config\StrictBoolean;

/*
|--------------------------------------------------------------------------
| Payment Configuration
|--------------------------------------------------------------------------
|
| Configuration only. No gateway client, HTTP call or signing implementation
| lives in this file. The concrete gateway drivers (Stripe, bKash, Nagad,
| Crypto, Bank Transfer) are bound in
| App\Services\Payment\PaymentGatewayManager and live in
| app/Services/Payment/Drivers — this file is the single place an operator
| enables a provider, supplies its credentials and, for manual bank
| settlement, supplies the REAL settlement account details.
|
| SECRETS
| Every credential is read from the environment and defaults to null. Never
| write a real key, secret, password or private key into this file.
|
*/

return [

    /*
    |--------------------------------------------------------------------------
    | Default Gateway
    |--------------------------------------------------------------------------
    */

    'default_gateway' => env('PAYMENT_DEFAULT_GATEWAY', 'stripe'),

    /*
    |--------------------------------------------------------------------------
    | Supported Currencies
    |--------------------------------------------------------------------------
    */

    'country' => strtoupper((string) env('APP_COUNTRY', 'TH')),
    'currency' => [
        'default' => env('FINANCE_DEFAULT_CURRENCY', 'THB'),
        'supported' => ['THB', 'USD', 'BDT'],
    ],

    /*
    |--------------------------------------------------------------------------
    | Supported Banks (for Thai bank wire and withdrawal settlement)
    |--------------------------------------------------------------------------
    */

    'supported_banks' => [
        'Bangkok Bank' => 'Bangkok Bank (BBL)',
        'Kasikornbank' => 'Kasikornbank (KBANK)',
        'Siam Commercial Bank' => 'Siam Commercial Bank (SCB)',
        'Krungthai Bank' => 'Krungthai Bank (KTB)',
        'Bank of Ayudhya' => 'Bank of Ayudhya (Krungsri)',
        'TTB Bank' => 'TMBThanachart Bank (TTB)',
        'Government Savings Bank' => 'Government Savings Bank (GSB)',
    ],

    /*
    |--------------------------------------------------------------------------
    | Payment Methods
    |--------------------------------------------------------------------------
    |
    | Backing values of App\Enums\PaymentMethod, used to validate an inbound
    | deposit or withdrawal request before a gateway is resolved.
    |
    */

    'methods' => array_column(PaymentMethod::cases(), 'value'),

    // Market allowlists are enforced by PaymentGatewayManager before any
    // payment method is displayed or resolved. Countries are ISO 3166-1 alpha-2.
    'markets' => [
        'stripe' => ['currencies' => ['THB', 'USD'], 'countries' => ['TH', 'US']],
        'bkash' => ['currencies' => ['BDT'], 'countries' => ['BD']],
        'nagad' => ['currencies' => ['BDT'], 'countries' => ['BD']],
        'bank_transfer' => ['currencies' => ['THB'], 'countries' => ['TH']],
        'promptpay' => ['currencies' => ['THB'], 'countries' => ['TH']],
        'thai_bank' => ['currencies' => ['THB'], 'countries' => ['TH']],
    ],

    /*
    |--------------------------------------------------------------------------
    | Public fee providers (public fee-schedule bridge)
    |--------------------------------------------------------------------------
    |
    | Maps the STABLE PUBLIC provider keys used by config/fees.php's
    | provider-specific rows onto the payment layer. 'method' names the live
    | PaymentMethod backing value when this platform actually operates that
    | provider's lane today; null means the provider exists only as a public
    | schedule row (documented fee, no executable lane, therefore no fee is
    | ever charged through it and no gateway is consulted for it).
    |
    | SECRETS: none. This map carries provider IDENTITY only — no gateway
    | credential, webhook secret, merchant id or internal margin. Fee VALUES
    | live in config/fees.php; gateway credentials live in 'gateways' below
    | and are never read by the public fees surface.
    |
    | The public Fees page and the fee-preview endpoint whitelist provider
    | input against exactly these keys, so a request can never name an
    | arbitrary internal provider.
    |
    */

    'public_fees' => [
        'providers' => [
            'bank' => [
                'method' => PaymentMethod::BankTransfer->value,
                'live' => true,
            ],
            'skrill' => [
                'method' => null,
                'live' => false,
            ],
            'neteller' => [
                'method' => null,
                'live' => false,
            ],
            'paypal' => [
                'method' => null,
                'live' => false,
            ],
            'perfect_money' => [
                'method' => null,
                'live' => false,
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Deposits
    |--------------------------------------------------------------------------
    |
    | Monetary bounds are decimal strings and mirror config/finance.php so the
    | wallet engine and the payment layer cannot disagree.
    |
    */

    'deposit' => [
        'enabled' => true,
        'min' => (string) env('FINANCE_MIN_DEPOSIT', '50.00'),
        'max' => (string) env('FINANCE_MAX_DEPOSIT', '500000.00'),
        'auto_confirm' => StrictBoolean::orClosed(env('FINANCE_DEPOSIT_AUTO_CONFIRM')),
        'reference_prefix' => 'DP',
        'expire_unpaid_after_minutes' => 30,
        'allowed_methods' => [
            PaymentMethod::Stripe->value,
            PaymentMethod::Bkash->value,
            PaymentMethod::Nagad->value,
            PaymentMethod::BankTransfer->value,
            PaymentMethod::PromptPay->value,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Withdrawals
    |--------------------------------------------------------------------------
    */

    'withdrawal' => [
        'enabled' => true,
        'min' => (string) env('FINANCE_MIN_WITHDRAWAL', '100.00'),
        'max' => (string) env('FINANCE_MAX_WITHDRAWAL', '500000.00'),
        'require_manual_approval' => true,
        'processing_hours' => (int) env('FINANCE_WITHDRAWAL_PROCESSING_HOURS', 24),
        'reference_prefix' => 'WD',
        'encrypt_payout_details' => true,
        // PromptPay is deliberately NOT a withdrawal rail. It is a Thai deposit
        // rail (a payer pushes money to a merchant proxy ID); the payout side of
        // the Thai lane is `thai_bank` via THAI_PAYOUT_*, and
        // PaymentGatewayManager::isWithdrawalCapable() maps promptpay onto that
        // rail behind four thai_payout.promptpay.* flags that all default false.
        // Listing it here advertised a payout method the site cannot actually
        // disburse, which is exactly what the public withdrawal-methods contract
        // test refuses to see.
        'allowed_methods' => [
            PaymentMethod::Bkash->value,
            PaymentMethod::Nagad->value,
            PaymentMethod::BankTransfer->value,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Withdrawal routing
    |--------------------------------------------------------------------------
    |
    | How the SYSTEM chooses the rail that actually pays a withdrawal. This is
    | not a player preference: the player chooses a supported payout method,
    | such as `bank_transfer`, and WithdrawalDisbursementService decides from server-side
    | configuration plus the stored destination whether the automated Thai
    | bank rail can pay it, persisting the chosen key on the withdrawal before
    | the external call.
    |
    | `prefer_automated_payout` is the deployment-wide preference. The amount
    | bounds are optional: an unset bound is ABSENT, not zero, so a deployment
    | that sets neither lets every amount through to the destination check
    | rather than refusing all automation.
    |
    */

    'withdrawal_routing' => [
        'prefer_automated_payout' => StrictBoolean::orDefault(env('PAYMENT_WITHDRAWAL_ROUTING_PREFER_AUTOMATED'), true),
        'min_amount' => env('PAYMENT_WITHDRAWAL_ROUTING_MIN_AMOUNT'),
        'max_amount' => env('PAYMENT_WITHDRAWAL_ROUTING_MAX_AMOUNT'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Callback / Redirect URLs
    |--------------------------------------------------------------------------
    |
    | Paths may be relative ("/payment/success") or absolute
    | ("${APP_URL}/payment/success"). They are read in two places that can
    | never drift apart: the gateway drivers build provider success/cancel
    | URLs from them, and routes/web.php registers the browser-return
    | routes (PaymentCallbackController) from the same values. Those pages
    | are presentation only — payment state changes only via verified
    | webhooks.
    |
    */

    'callback' => [
        'success_url' => env('PAYMENT_SUCCESS_URL', '/payment/success'),
        'failure_url' => env('PAYMENT_FAILURE_URL', '/payment/failure'),
        'cancel_url' => env('PAYMENT_CANCEL_URL', '/payment/cancel'),
        'pending_url' => '/payment/pending',
    ],

    /*
    |--------------------------------------------------------------------------
    | Idempotency
    |--------------------------------------------------------------------------
    |
    | Gateway callbacks and webhooks are retried by providers, so every inbound
    | notification is keyed and deduplicated before it can touch the ledger.
    |
    */

    'idempotency' => [
        'enabled' => true,
        'header' => env('IDEMPOTENCY_KEY_HEADER', 'X-Idempotency-Key'),
        'cache_ttl' => (int) env('IDEMPOTENCY_CACHE_TTL', 86400),
        'cache_prefix' => 'payment:idempotency:',
    ],

    /*
    |--------------------------------------------------------------------------
    | Webhook Validation
    |--------------------------------------------------------------------------
    |
    | Consumed by App\Http\Middleware\VerifyWebhookSignature, which reads the
    | per-gateway 'webhook_secret' and 'signature_header' values below.
    |
    */

    'webhook' => [
        'verify_signature' => true,
        'algorithm' => 'sha256',
        'max_age_seconds' => 300,
        'replay_protection' => true,
        'persist_receipts' => true,
        'replay_cache_prefix' => 'payment:webhook:seen:',

        /*
        |----------------------------------------------------------------------
        | Durable replay guard retention
        |----------------------------------------------------------------------
        |
        | How long a signed webhook payload is remembered in
        | webhook_replay_guards, as the substrate for replay refusal. Shorter
        | reopens the replay window; longer costs a few dozen bytes per delivery.
        |
        | 30 days is chosen to comfortably exceed every gateway's retry horizon
        | (Stripe retries for up to 3 days; bKash and Nagad for far less) while
        | keeping the table small enough that pruning stays an indexed range
        | delete.
        |
        | This is NOT the same thing as webhook.max_age_seconds, which bounds how
        | OLD a signed request may be. This bounds how long we remember that we
        | have seen it.
        |
        */
        'replay_guard_retention_days' => (int) env('WEBHOOK_REPLAY_GUARD_RETENTION_DAYS', 30),
        'require_https' => true,
        'log_rejections' => true,
    ],

    /*
    |--------------------------------------------------------------------------
    | Gateways
    |--------------------------------------------------------------------------
    |
    | Concrete gateway drivers live in app/Services/Payment/Drivers (Stripe,
    | bKash, Nagad, Crypto, Bank Transfer). Each gateway is enabled via
    | environment flags and requires valid credentials or operator settlement
    | configuration before it can be used in deposit or withdrawal operations.
    |
    */

    'gateways' => [

        'stripe' => [
            'enabled' => StrictBoolean::orClosed(env('STRIPE_ENABLED')),
            'driver' => 'stripe',
            'key' => env('STRIPE_KEY'),
            'secret' => env('STRIPE_SECRET'),
            'webhook_secret' => env('STRIPE_WEBHOOK_SECRET'),
            'signature_header' => 'Stripe-Signature',
            'currency' => env('FINANCE_DEFAULT_CURRENCY', 'THB'),
            'supported_currencies' => ['THB', 'USD'],
            'supports_deposit' => true,
            'supports_withdrawal' => false,
        ],

        'bkash' => [
            'enabled' => StrictBoolean::orClosed(env('BKASH_ENABLED')),
            'driver' => 'bkash',
            'app_key' => env('BKASH_APP_KEY'),
            'app_secret' => env('BKASH_APP_SECRET'),
            'username' => env('BKASH_USERNAME'),
            'password' => env('BKASH_PASSWORD'),
            // Manual rail (ManualWalletDepositSettlementService / BkashGateway): 'api' uses the provider API,
            // 'manual' shows merchant_name/merchant_number to the player and credits only after staff verify the TrxID.
            'mode' => env('BKASH_MODE', 'api'),
            'merchant_name' => env('BKASH_MERCHANT_NAME'),
            'merchant_number' => env('BKASH_MERCHANT_NUMBER'),
            'base_url' => env('BKASH_BASE_URL'),
            'sandbox' => StrictBoolean::orDefault(env('BKASH_SANDBOX'), true),
            'webhook_secret' => env('BKASH_APP_SECRET'),
            'signature_header' => 'X-Bkash-Signature',
            'currency' => 'BDT',
            'supported_currencies' => ['BDT'],
            'supports_deposit' => true,
            'supports_withdrawal' => true,
        ],

        'nagad' => [
            'enabled' => StrictBoolean::orClosed(env('NAGAD_ENABLED')),
            'driver' => 'nagad',
            'merchant_id' => env('NAGAD_MERCHANT_ID'),
            'merchant_number' => env('NAGAD_MERCHANT_NUMBER'),
            // Manual rail, same meaning as the bKash keys above.
            'mode' => env('NAGAD_MODE', 'api'),
            'merchant_name' => env('NAGAD_MERCHANT_NAME'),
            'app_key' => env('NAGAD_APP_KEY'),
            'app_secret' => env('NAGAD_APP_SECRET'),
            'public_key' => env('NAGAD_PUBLIC_KEY'),
            'private_key' => env('NAGAD_PRIVATE_KEY'),
            'base_url' => env('NAGAD_BASE_URL'),
            'sandbox' => StrictBoolean::orDefault(env('NAGAD_SANDBOX'), true),
            'webhook_secret' => env('NAGAD_APP_SECRET'),
            'signature_header' => 'X-Nagad-Signature',
            'currency' => 'BDT',
            'supported_currencies' => ['BDT'],
            'supports_deposit' => true,
            'supports_withdrawal' => true,
        ],

        'crypto' => [
            'enabled' => StrictBoolean::orClosed(env('CRYPTO_ENABLED')),
            'driver' => 'crypto',
            'provider' => env('CRYPTO_PROVIDER'),
            'api_key' => env('CRYPTO_GATEWAY_API_KEY'),
            'api_secret' => env('CRYPTO_GATEWAY_API_SECRET'),
            'webhook_secret' => env('CRYPTO_GATEWAY_WEBHOOK_SECRET'),
            'signature_header' => 'X-Crypto-Signature',
            'currency' => 'USD',
            'supported_currencies' => ['USD'],
            'confirmations_required' => 3,
            'supports_deposit' => true,
            'supports_withdrawal' => true,
        ],

        'promptpay' => [
            'enabled' => StrictBoolean::orClosed(env('PROMPTPAY_ENABLED')),
            'driver' => 'promptpay',
            'merchant_id' => env('PROMPTPAY_MERCHANT_ID'),
            'merchant_name' => env('PROMPTPAY_MERCHANT_NAME', 'Thai Lottery'),
            'qr_expiry_minutes' => (int) env('PROMPTPAY_QR_EXPIRY_MINUTES', 15),
            'currency' => 'THB',
            'supported_currencies' => ['THB'],
            'supports_deposit' => true,
            'supports_withdrawal' => false,
            'supports_webhook' => true,
            'webhook_secret' => env('KBANK_WEBHOOK_SECRET'),
            'signature_header' => 'X-KBANK-Signature',
            'bank_webhooks' => [
                'kbank' => [
                    'webhook_secret' => env('KBANK_WEBHOOK_SECRET'),
                    'signature_header' => 'X-KBANK-Signature',
                ],
                'scb' => [
                    'webhook_secret' => env('SCB_WEBHOOK_SECRET'),
                    'signature_header' => 'X-SCB-Signature',
                ],
            ],
        ],

        'bank_transfer' => [
            // Bank transfer settlement configuration. Requires valid operator
            // settlement details (bank_name, account_number, account_name) in
            // the environment; otherwise BankTransferGateway fails closed.
            'enabled' => StrictBoolean::orClosed(env('BANK_TRANSFER_ENABLED')),
            'driver' => 'bank_transfer',
            'supported_currencies' => ['THB'],
            'supports_deposit' => true,
            'supports_withdrawal' => true,
            'settlement' => [
                'bank_name' => env('BANK_TRANSFER_BANK_NAME'),
                'account_number' => env('BANK_TRANSFER_ACCOUNT_NUMBER'),
                'account_name' => env('BANK_TRANSFER_ACCOUNT_NAME'),
                'instructions' => env('BANK_TRANSFER_INSTRUCTIONS'),
            ],
        ],

        /*
         * The automated Thai bank payout rail.
         *
         * NOT A PAYMENT METHOD. App\Enums\PaymentMethod has no `thai_bank`
         * case on purpose: this rail is never chosen by a client, it is chosen
         * by WithdrawalDisbursementService from `thai_payout.enabled`, the
         * deployment's routing preference, the amount bounds and the stored
         * destination, and the chosen key is persisted on the withdrawal
         * before the external call so every later reader resolves the same
         * driver. A player still asks for `bank_transfer`.
         *
         * This block exists so the manager arm
         * (PaymentGatewayManager::driver('thai_bank')) and the reconciliation,
         * polling and webhook lanes have a configured identity to resolve,
         * and so an operator can see the rail in the same place as every
         * other gateway. The operational switch is `thai_payout.enabled` and
         * the per-bank switch `thai_payout.banks.<bank>.enabled`; this arm
         * declares identity and direction only — deposits never arrive here.
         */
        'thai_bank' => [
            'enabled' => StrictBoolean::orClosed(env('THAI_PAYOUT_ENABLED')),
            'driver' => 'thai_bank',
            'currency' => 'THB',
            'supported_currencies' => ['THB'],
            'supports_deposit' => false,
            'supports_withdrawal' => true,
            'supports_webhook' => true,
            'webhook_secret' => env('THAI_PAYOUT_WEBHOOK_SECRET'),
            'signature_header' => env('THAI_PAYOUT_SIGNATURE_HEADER', 'X-ThaiBank-Signature'),
        ],

    ],

    'checkout_lookup' => [
        'stripe' => [
            'enabled' => StrictBoolean::orClosed(env('STRIPE_CHECKOUT_LOOKUP_ENABLED')),
        ],
    ],

    'deposit_settlement' => [
        'stripe' => [
            'enabled' => StrictBoolean::orClosed(env('STRIPE_DEPOSIT_SETTLEMENT_ENABLED')),
        ],
    ],

    'deposit_review' => [
        'stripe' => [
            'enabled' => StrictBoolean::orClosed(env('STRIPE_DEPOSIT_REVIEW_ENABLED')),
            'webhook_secret' => env('STRIPE_DEPOSIT_FOLLOWUP_WEBHOOK_SECRET'),
        ],
    ],

    'deposit_followup_routing' => [
        'stripe' => [
            'enabled' => StrictBoolean::orClosed(env('STRIPE_DEPOSIT_FOLLOWUP_ROUTING_ENABLED')),
        ],
    ],

    'deposit_followup_sweep' => [
        'stripe' => [
            'enabled' => StrictBoolean::orClosed(env('STRIPE_DEPOSIT_FOLLOWUP_SWEEP_ENABLED')),
            'actor_id' => env('STRIPE_DEPOSIT_FOLLOWUP_SWEEP_ACTOR_ID'),
        ],
    ],

    'refund_recovery' => [
        'stripe' => [
            'enabled' => StrictBoolean::orClosed(env('STRIPE_REFUND_RECOVERY_ENABLED')),
        ],
    ],

];
